package com.example.post.list.app.model;

import com.example.post.list.app.model.persistence.entities.Post;

import java.util.List;


/**
 * This interface contains the contract of interactions between the Repository and presenter
 */
public interface PostsContractRepository {


    interface Repository {
        void getPosts();

        void refreshPost();

        void getPost(int post);

        void removePost(int postId);

        void updatePost(Post post);

        void removeAllPosts();

        void release();

        void init(ModelOperations operations);
    }


    interface ModelOperations {

        void onPostList(List<Post> postList);

        void onRemovedPost();

        void onRemovedPostList();

        void onPost(Post post);

        void onError(String message);

    }

}
