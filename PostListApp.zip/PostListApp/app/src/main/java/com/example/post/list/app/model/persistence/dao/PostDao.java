package com.example.post.list.app.model.persistence.dao;


import com.example.post.list.app.model.persistence.entities.Post;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;
import io.reactivex.Completable;
import io.reactivex.Flowable;

/**
 * this interface defines the database operations using {@link androidx.room.Room}
 */
@Dao
public interface PostDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    Completable insertPost(Post post);

    @Query("SELECT * FROM posts")
    Flowable<List<Post>> getPosts();

    @Query("SELECT * FROM posts WHERE id = :id")
    Flowable<Post> findPostById(int id);

    @Delete
    Completable deletePost(Post... posts);

    @Query("DELETE FROM posts WHERE id = :id")
    Completable deletePost(int id);

    @Query("DELETE FROM posts")
    Completable deletePosts();

    @Update
    Completable update(Post post);


}
