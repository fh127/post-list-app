package com.example.post.list.app.presentation.presenters;

import com.example.post.list.app.model.PostsContractRepository;
import com.example.post.list.app.model.persistence.entities.Post;

import java.util.List;

public class MainPresenterImpl extends BasePresenter<PostContractMainView.View> implements PostContractMainView.Presenter, PostsContractRepository.ModelOperations {

    PostsContractRepository.Repository repository;

    public MainPresenterImpl(PostContractMainView.View view, PostsContractRepository.Repository repository) {
        super(view);
        this.repository = repository;
    }

    @Override
    public void init() {
        super.init();
        repository.init(this);
    }

    @Override
    public void refreshList() {

    }

    @Override
    public void getPostList() {

    }

    @Override
    public void removePost(Post post) {

    }

    @Override
    public void removePosts() {

    }

    @Override
    public void updatePostState() {

    }

    @Override
    public void onPostList(List<Post> postList) {

    }

    @Override
    public void onRemovedPost() {

    }

    @Override
    public void onRemovedPostList() {

    }

    @Override
    public void onPost(Post post) {

    }

    @Override
    public void onError(String message) {

    }

    @Override
    public void release() {
        super.release();
        repository.release();
    }
}
