package com.example.post.list.app.model.persistence;

import android.content.Context;

import com.example.post.list.app.model.persistence.dao.PostDao;
import com.example.post.list.app.model.persistence.dao.PostDatabase;
import com.example.post.list.app.model.persistence.entities.Post;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;

import io.reactivex.Completable;
import io.reactivex.Flowable;

/**
 * This is the implementation of {@link LocalDataSource}
 */
@Singleton
public class LocalDataSourceImpl implements LocalDataSource {

    private final PostDao postDao;

    @Inject
    public LocalDataSourceImpl(Context context) {
        PostDatabase database = PostDatabase.getInstance(context);
        this.postDao = database.postDao();
    }

    @Override
    public Completable addPost(Post post) {
        return null;

    }

    @Override
    public Flowable<List<Post>> getPosts() {
        return postDao.getPosts();
    }

    @Override
    public Flowable<Post> findPostById(int id) {
        return postDao.findPostById(id);
    }

    @Override
    public Completable deletePost(Post... posts) {
        return postDao.deletePost(posts);
    }

    @Override
    public Completable deletePost(int postId) {
        return postDao.deletePost(postId);
    }

    @Override
    public Completable deletePosts() {
        return postDao.deletePosts();
    }

    @Override
    public Completable updatePost(Post post) {
        return postDao.update(post);
    }
}
