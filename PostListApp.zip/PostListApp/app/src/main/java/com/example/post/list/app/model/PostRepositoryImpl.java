package com.example.post.list.app.model;

import android.util.Log;

import com.example.post.list.app.model.api.ServiceApiManager;
import com.example.post.list.app.model.api.dto.CommentDto;
import com.example.post.list.app.model.api.dto.PostDto;
import com.example.post.list.app.model.api.dto.UserDto;
import com.example.post.list.app.model.persistence.LocalDataSource;
import com.example.post.list.app.model.persistence.entities.Post;
import com.example.post.list.app.utils.CollectionsUtils;
import com.example.post.list.app.utils.PostUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.inject.Inject;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.schedulers.Schedulers;

import static com.example.post.list.app.model.api.ServiceApiManager.OnRemovedPost;
import static com.example.post.list.app.utils.Constants.ERROR_DELETE_POSTS;
import static com.example.post.list.app.utils.Constants.ERROR_POST_REQUEST;
import static com.example.post.list.app.utils.Constants.ERROR_SAVE_POST;
import static com.example.post.list.app.utils.Constants.ERROR_UNKNOWN_POST;
import static io.reactivex.Observable.fromIterable;
import static io.reactivex.Observable.zip;

/**
 * this implementation of  Post Repository:
 * - Handles the local storage and network connections
 * - Handles cache rules
 * - Encapsulates the logic of third-party libraries and keep interface communications of Java core.
 */
public class PostRepositoryImpl implements PostsContractRepository.Repository {

    private static final String TAG = PostRepositoryImpl.class.getSimpleName();
    private PostsContractRepository.ModelOperations listener;
    private ServiceApiManager apiManager;
    private LocalDataSource localDataSource;
    private CompositeDisposable compositeDisposable;

    @Inject
    public PostRepositoryImpl(ServiceApiManager apiManager, LocalDataSource localDataSource) {
        this.apiManager = apiManager;
        this.localDataSource = localDataSource;
        this.compositeDisposable = new CompositeDisposable();
    }

    @Override
    public void init(PostsContractRepository.ModelOperations modelOperations) {
        this.listener = modelOperations;
    }

    @Override
    public void getPosts() {
        compositeDisposable.add(localDataSource.getPosts()
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(this::checkPostList,
                        throwable -> fetchPostRequest()));
    }

    private void checkPostList(List<Post> postList) {
        if (!CollectionsUtils.isEmpty(postList)) {
            listener.onPostList(postList);
            return;
        }

        refreshPost();
    }

    /**
     * this method gets post list from services
     */
    private void fetchPostRequest() {
        apiManager.getPosts(this::processPostList);
    }

    /**
     * this method validates the services response and transforms the dto class to business model
     *
     * @param postDtos
     */
    private void processPostList(List<PostDto> postDtos) {
        if (CollectionsUtils.isEmpty(postDtos)) {
            listener.onError(ERROR_POST_REQUEST);
            return;
        }

        List<Post> posts = Collections.emptyList();
        for (PostDto postDto : postDtos) {
            Post post = PostUtils.buildPost(postDto, PostUtils.getInitialState(postDto.getId()));
            posts.add(post);
        }
        savePostList(posts);
        listener.onPostList(posts);
    }

    private void savePostList(List<Post> posts) {
        compositeDisposable.add(fromIterable(new ArrayList<>(posts))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .map(post -> localDataSource.addPost(post))
                .subscribe(completable -> Log.d(TAG, "success saved post"),
                        throwable -> listener.onError(ERROR_SAVE_POST)));

    }

    @Override
    public void refreshPost() {
        fetchPostRequest();
    }

    @Override
    public void getPost(int postId) {
        compositeDisposable.add(localDataSource.findPostById(postId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(this::validatePostData,
                        throwable -> listener.onError(ERROR_UNKNOWN_POST)));
    }

    /**
     * this method validates if the post has complete data
     * another case the post object is processed to complete the data
     *
     * @param post
     */
    private void validatePostData(Post post) {
        if (!post.getUser().isEmpty() || !CollectionsUtils.isEmpty(post.getComments())) {
            listener.onPost(post);
            return;
        }

        // get comments and user info from services
        compositeDisposable.add(zip(apiManager.getCommentsByPostId(post.getId()), apiManager.getUser(post.getUserReferenceId()), (commentDtos, userDto) -> fillPost(post, userDto, commentDtos))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(post1 -> listener.onPost(post1),
                        throwable -> listener.onError(ERROR_UNKNOWN_POST)
                ));

    }

    private Post fillPost(Post post, UserDto userDto, List<CommentDto> commentDtos) {
        if (userDto != null && userDto.getId() == post.getUserReferenceId()) {
            post.setUser(PostUtils.buildUser(userDto));
        }

        if (!CollectionsUtils.isEmpty(commentDtos)) {
            post.setComments(PostUtils.buildComments(commentDtos));
        }
        updatePost(post);
        return post;
    }


    @Override
    public void removePost(int postId) {
        apiManager.removePost(postId, new OnRemovedPost() {
            @Override
            public void onRemovedPost() {
                compositeDisposable.add(localDataSource.deletePost(postId)
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(() -> listener.onRemovedPost(),
                                throwable -> listener.onError(ERROR_DELETE_POSTS)));
            }

            @Override
            public void onError() {
                listener.onError(ERROR_DELETE_POSTS);
            }
        });
    }


    @Override
    public void updatePost(Post post) {
        compositeDisposable.add(localDataSource.updatePost(post)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(() -> Log.d(TAG, "post updated"),
                        throwable -> listener.onError(ERROR_SAVE_POST)));
    }

    @Override
    public void removeAllPosts() {
        compositeDisposable.add(localDataSource.deletePosts()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(() -> listener.onRemovedPostList(),
                        throwable -> listener.onError(ERROR_DELETE_POSTS)));
    }

    @Override
    public void release() {
        apiManager.clear();
        if (compositeDisposable.size() > 0 && !compositeDisposable.isDisposed())
            compositeDisposable.clear();
    }
}
