package com.example.post.list.app.utils;

import android.support.annotation.IntDef;

import com.example.post.list.app.model.api.dto.CommentDto;
import com.example.post.list.app.model.api.dto.PostDto;
import com.example.post.list.app.model.api.dto.UserDto;
import com.example.post.list.app.model.persistence.entities.Comment;
import com.example.post.list.app.model.persistence.entities.Post;
import com.example.post.list.app.model.persistence.entities.User;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;


/**
 * this class contains different utilities to handle
 * the {@link com.example.post.list.app.model.persistence.entities.Post} object according the requirements
 */
public class PostUtils {

    private final static int MAX_LIST_VALUE_INITIAL_STATE = 20;

    @Retention(RetentionPolicy.SOURCE)
    @IntDef({
            NONE,
            INITIAL_SELECTION,
            FAVORITE
    })
    public @interface PostState {
    }

    public static final int NONE = 0;
    public static final int INITIAL_SELECTION = 1;
    public static final int FAVORITE = 2;

    public static Post buildPost(PostDto postDto, @PostState int state) {
        Post post = new Post();
        post.setId(postDto.getId());
        post.setBody(postDto.getBody());
        post.setTitle(postDto.getTitle());
        post.setState(state);
        post.setUserReferenceId(postDto.getUserId());
        return post;
    }

    public static List<Comment> buildComments(List<CommentDto> commentDtos) {
        List<Comment> comments = Collections.emptyList();
        for (CommentDto commentDto : commentDtos) {
            Comment comment = new Comment(commentDto.getName(), commentDto.getBody());
            comments.add(comment);
        }
        return comments;
    }


    public static User buildUser(UserDto userDto) {
        User user = new User();
        user.setId(userDto.getId());
        user.setEmail(userDto.getEmail());
        user.setName(userDto.getName());
        user.setPhone(userDto.getPhone());
        user.setWebsite(userDto.getWebsite());
        return user;
    }

    public static @PostState
    int getInitialState(long id) {
        return id > MAX_LIST_VALUE_INITIAL_STATE
                ? PostUtils.NONE
                : PostUtils.INITIAL_SELECTION;
    }

}
