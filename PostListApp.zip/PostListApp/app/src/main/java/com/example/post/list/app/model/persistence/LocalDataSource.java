package com.example.post.list.app.model.persistence;

import com.example.post.list.app.model.persistence.entities.Post;

import java.util.List;

import io.reactivex.Completable;
import io.reactivex.Flowable;

/**
 * This interface defines the communication of persistence layer
 */
public interface LocalDataSource {

    Completable addPost(Post post);

    Flowable<List<Post>> getPosts();

    Flowable<Post> findPostById(int id);

    Completable deletePost(Post... posts);

    Completable deletePost(int postId);

    Completable deletePosts();

    Completable updatePost(Post post);
}
