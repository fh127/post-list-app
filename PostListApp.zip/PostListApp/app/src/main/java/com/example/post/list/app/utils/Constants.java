package com.example.post.list.app.utils;

public class Constants {

    public static final String ERROR_POST_REQUEST = "There is an error connection, Try again";
    public static final String ERROR_UNKNOWN_POST = "There is an UnKnown Error";
    public static final String ERROR_DELETE_POSTS = "Can't Remove the post or posts";
    public static final String ERROR_SAVE_POST = "Can't Save or update Post in Cache";
}
