package com.example.post.list.app.di;

import com.example.post.list.app.model.PostRepositoryImpl;
import com.example.post.list.app.model.PostsContractRepository.Repository;
import com.example.post.list.app.presentation.presenters.MainPresenterImpl;
import com.example.post.list.app.presentation.presenters.PostContractMainView;
import com.example.post.list.app.presentation.presenters.PostContractMainView.Presenter;

import dagger.Module;
import dagger.Provides;

@Module
public class MainPresenterModule {

    @Provides
    Repository providesRepository(PostRepositoryImpl repository) {
        return repository;
    }

    @Provides
    Presenter providesMainPresenter(PostContractMainView.View view, Repository repository){
        return new MainPresenterImpl(view, repository);
    }


}
