package com.example.post.list.app.presentation.presenters;

import com.example.post.list.app.model.persistence.entities.Post;

import java.util.List;

/**
 * This interface contains the contract of interactions between view and presenter
 *
 */
public interface PostContractMainView {


    interface  Presenter{

        void refreshList();

        void getPostList();

        void removePost(Post post);

        void removePosts();

        void updatePostState();

    }

    interface View {

        void onPostList(List<Post> postList);

        void onPostListError();

        void onRefreshError();

        void onDeletePostsError();

        void onDeletePostError();

        void onUpdatedPost(Post post);

    }


}
