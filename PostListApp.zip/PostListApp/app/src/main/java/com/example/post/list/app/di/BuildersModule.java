package com.example.post.list.app.di;

import com.example.post.list.app.presentation.MainActivity;

import dagger.Module;
import dagger.android.ContributesAndroidInjector;

@Module
public abstract class BuildersModule {

    @ContributesAndroidInjector(modules = {MainViewModule.class, MainPresenterModule.class})
    abstract MainActivity bindMainActivity();

    // Add bindings for other sub-components here
}