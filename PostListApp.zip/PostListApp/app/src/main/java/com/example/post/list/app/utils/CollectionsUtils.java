package com.example.post.list.app.utils;

import java.util.List;
import java.util.Map;

/**
 * this is utiliy class for Collection validations
 */
public class CollectionsUtils {


    public static boolean isEmpty(List list) {
        return list != null && list.isEmpty();
    }

    public static boolean isEmpty(Map map) {
        return map != null && map.isEmpty();
    }
}
